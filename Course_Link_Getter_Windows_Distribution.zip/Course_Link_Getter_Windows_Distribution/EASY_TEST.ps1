# Course Link Getter - Easy Test
Write-Host "🧪 Course Link Getter - Easy Test" -ForegroundColor Green
Write-Host "=" * 40 -ForegroundColor Green

if (Test-Path "release/Course_Link_Getter-Portable.exe") {
    Write-Host "✅ Portable executable found" -ForegroundColor Green
    Write-Host "🚀 Testing portable version..." -ForegroundColor Yellow
    
    try {
        $process = Start-Process -FilePath "release/Course_Link_Getter-Portable.exe" -PassThru
        Start-Sleep -Seconds 3
        
        if (-not $process.HasExited) {
            Write-Host "✅ Application started successfully!" -ForegroundColor Green
            Write-Host "🔄 Closing application..." -ForegroundColor Yellow
            $process.CloseMainWindow()
            Start-Sleep -Seconds 2
            if (-not $process.HasExited) {
                $process.Kill()
            }
            Write-Host "✅ Test completed successfully!" -ForegroundColor Green
        } else {
            Write-Host "❌ Application exited unexpectedly" -ForegroundColor Red
        }
    } catch {
        Write-Host "❌ Test failed: $($_.Exception.Message)" -ForegroundColor Red
    }
} else {
    Write-Host "❌ Portable executable not found" -ForegroundColor Red
    Write-Host "Please run EASY_BUILD.bat first" -ForegroundColor Yellow
}

Write-Host "`nPress any key to continue..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
