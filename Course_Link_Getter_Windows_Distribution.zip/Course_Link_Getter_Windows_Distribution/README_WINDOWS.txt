Course Link Getter - Windows Distribution Package
================================================

This package contains everything needed to build Course Link Getter for Windows.

QUICK START:
-----------
1. Double-click: build_windows.bat
2. Wait for build to complete
3. Find your files in: release/

WHAT YOU GET:
------------
- Course_Link_Getter-Portable.exe (35-50 MB)
  → Run directly, no installation needed
  
- Course_Link_Getter-Setup-x64.exe (40-60 MB)  
  → Windows installer with shortcuts

REQUIREMENTS:
------------
- Windows 10/11 x64
- Python 3.8+ (will be installed automatically if missing)
- Internet connection (for downloading build tools)

BUILD PROCESS:
-------------
The build script will automatically:
✓ Check Python installation
✓ Download PyInstaller, NSIS, UPX
✓ Create isolated build environment
✓ Build portable executable
✓ Create Windows installer
✓ Generate checksums
✓ Run automated tests

TESTING:
--------
After build, run:
powershell -ExecutionPolicy Bypass -File test_windows_build.ps1

This will test both executables to ensure they work correctly.

TROUBLESHOOTING:
---------------
- If Python not found: Install from https://python.org
- If build fails: Check internet connection
- If app won't run: Check Windows Defender settings
- If installer fails: Run as Administrator

SUPPORT:
--------
- Build Guide: README_BUILD.md
- Test Script: test_windows_build.ps1
- Source Code: course_link_getter/

The build process is fully automated and handles all dependencies.
