# 🎓 Course Link Getter

## 🚀 Quick Start

1. **Download** this package
2. **Run** `Course_Link_Getter` (double-click)
3. **Enjoy** the application!

## ✨ Features

- ✅ **26 courses** loaded automatically
- ✅ **Search and filter** functionality  
- ✅ **Copy links** to clipboard
- ✅ **Export to CSV**
- ✅ **Modern UI** with beautiful interface
- ✅ **No installation** required

## 🎯 System Requirements

- **Darwin** operating system
- **No additional software** required
- **All dependencies** included

## 📱 How to Use

1. **Launch** the application
2. **Search** for courses using the search bar
3. **Filter** by category or subcategory
4. **Click "Get Link"** to copy course links
5. **Use "Copy Visible Links"** for bulk copy
6. **Export to CSV** for data backup

## 🔧 Troubleshooting

- **App won't start**: Make sure you have the right operating system
- **Slow startup**: First launch takes 3-5 seconds (normal)
- **Antivirus warning**: Some antivirus may flag new executables (normal)

## 📞 Support

For issues or questions:
- GitHub: https://github.com/HulkBetii/GetLink
- Repository: https://github.com/HulkBetii/GetLink.git

---
**Course Link Getter v1.0** - Built with Python and PyQt5
