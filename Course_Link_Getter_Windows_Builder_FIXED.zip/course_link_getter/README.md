## Course Link Getter

See the top-level `README.md` for up-to-date instructions. This per-folder README has been deprecated.
