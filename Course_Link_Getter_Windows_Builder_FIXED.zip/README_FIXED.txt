# 🪟 Course Link Getter - Windows EXE Builder (Fixed)

## 🚀 Quick Start

### Option 1: Automatic Build (Recommended)
1. **Double-click** `BUILD_WINDOWS_EXE_FIXED.bat`
2. **Follow** the on-screen instructions
3. **Wait** for the build to complete
4. **Find** your .exe file in the `dist` folder

### Option 2: Manual Build
If automatic build fails, follow these steps:

1. **Install Python** (if not installed):
   - Run `INSTALL_PYTHON.bat` for instructions
   - Or download from: https://www.python.org/downloads/
   - **IMPORTANT**: Check "Add Python to PATH" during installation

2. **Install Dependencies**:
   ```bash
   pip install -r requirements.txt
   pip install pyinstaller
   ```

3. **Build Executable**:
   ```bash
   python build_windows_exe.py
   ```

## 🔧 Troubleshooting

### Error: "Python was not found"
**Solution**: Install Python and add it to PATH
1. Download Python from: https://www.python.org/downloads/
2. During installation, check "Add Python to PATH"
3. Restart Command Prompt
4. Try again

### Error: "'pip' is not recognized"
**Solution**: Install pip or reinstall Python
1. Run: `python -m ensurepip --upgrade`
2. Or reinstall Python with PATH option

### Error: "Failed to install requirements"
**Solution**: Check internet connection
1. Make sure you have internet access
2. Try running: `pip install -r requirements.txt` manually
3. If still failing, try: `pip install --upgrade pip`

### Error: "Build failed"
**Solution**: Check error messages
1. Look at the error output above
2. Make sure all dependencies are installed
3. Try running: `python build_windows_exe.py` manually

## 📋 What you'll get

After successful build:
- `Course_Link_Getter.exe` - Single executable file (~40-50MB)
- No installation required - just double-click to run
- All 26 courses included
- Modern UI with search, filter, copy, and export features

## 🎯 System Requirements

- **Windows 10** or later
- **Python 3.8+** (will be checked automatically)
- **Internet connection** (for downloading dependencies)
- **~100MB free space** (for build process)

## 📁 Files included

- `course_link_getter/` - Application source code
- `build_windows_exe.py` - Python build script
- `build_windows_exe.bat` - Batch build script
- `BUILD_WINDOWS_EXE_FIXED.bat` - **Improved build launcher**
- `INSTALL_PYTHON.bat` - Python installation helper
- `requirements.txt` - Python dependencies
- `WINDOWS_BUILD_GUIDE.md` - Detailed build guide

## 🚀 Distribution

Once you have the .exe file:
1. **Share** the .exe file with anyone
2. **No installation** required - just double-click
3. **Works offline** - no internet needed
4. **Cross-platform** - works on any Windows 10+ computer

## 📞 Support

If you still have issues:
1. Check the error messages carefully
2. Make sure Python is properly installed
3. Try the manual build steps
4. Visit: https://github.com/HulkBetii/GetLink

---
**Course Link Getter v1.0** - Built with Python and PyQt5
