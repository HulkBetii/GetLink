# 🪟 Course Link Getter - Windows EXE Builder

## 🚀 Quick Start

1. **Download** this package to your Windows computer
2. **Double-click** `BUILD_WINDOWS_EXE.bat`
3. **Wait** for the build to complete
4. **Find** your .exe file in the `dist` folder

## 📋 What you'll get

- `Course_Link_Getter.exe` - Single executable file (~40-50MB)
- No installation required - just double-click to run
- All 26 courses included
- Modern UI with search, filter, copy, and export features

## 🔧 Manual Build (if needed)

If the automatic build fails, you can build manually:

```bash
# Install dependencies
pip install -r requirements.txt
pip install pyinstaller

# Build executable
python build_windows_exe.py
```

## 📁 Files included

- `course_link_getter/` - Application source code
- `build_windows_exe.py` - Python build script
- `build_windows_exe.bat` - Batch build script
- `BUILD_WINDOWS_EXE.bat` - Simple build launcher
- `requirements.txt` - Python dependencies
- `WINDOWS_BUILD_GUIDE.md` - Detailed build guide

## 🎯 Result

After building, you'll have:
- **Single .exe file** - No installation needed
- **Portable** - Runs on any Windows 10+ computer
- **Self-contained** - All dependencies included
- **26 courses** - Full course catalog
- **Modern UI** - Beautiful interface

## 🚀 Distribution

Once you have the .exe file, you can:
1. **Share** the .exe file with anyone
2. **No installation** required - just double-click
3. **Works offline** - no internet needed
4. **Cross-platform** - works on any Windows 10+ computer

---
**Course Link Getter v1.0** - Built with Python and PyQt5
